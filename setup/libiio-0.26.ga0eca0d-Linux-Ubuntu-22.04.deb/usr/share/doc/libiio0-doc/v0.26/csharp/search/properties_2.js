var searchData=
[
  ['format_142',['format',['../classiio_1_1Channel.html#a1b9214d70d53b882c863908754c39887',1,'iio::Channel']]]
];

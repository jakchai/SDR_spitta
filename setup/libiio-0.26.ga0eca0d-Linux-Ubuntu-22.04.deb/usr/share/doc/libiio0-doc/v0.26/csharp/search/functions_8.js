var searchData=
[
  ['set_5fblocking_5fmode_117',['set_blocking_mode',['../classiio_1_1IOBuffer.html#adcae94765967aafa22375b21e026c7a8',1,'iio::IOBuffer']]],
  ['set_5fkernel_5fbuffers_5fcount_118',['set_kernel_buffers_count',['../classiio_1_1Device.html#a9005ab45349aa4c98a6717847001d6fd',1,'iio::Device']]],
  ['set_5frate_119',['set_rate',['../classiio_1_1Trigger.html#ab12ed83717ef5ccd390a5912e2f0ab35',1,'iio::Trigger']]],
  ['set_5ftimeout_120',['set_timeout',['../classiio_1_1Context.html#a01a0558b0aec4442e71db52fcbb63793',1,'iio::Context']]],
  ['set_5ftrigger_121',['set_trigger',['../classiio_1_1Device.html#a5cf653e285c685648dfc66a5119595d4',1,'iio.Device.set_trigger()'],['../classiio_1_1Trigger.html#af8c80cf48e924780a1705c20032119c1',1,'iio.Trigger.set_trigger()']]],
  ['step_122',['step',['../classiio_1_1IOBuffer.html#a6bc109c422c32ded351060e83b3a69a1',1,'iio::IOBuffer']]]
];

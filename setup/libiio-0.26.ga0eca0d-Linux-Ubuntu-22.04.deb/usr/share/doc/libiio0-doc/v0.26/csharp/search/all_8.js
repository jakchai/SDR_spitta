var searchData=
[
  ['id_41',['id',['../classiio_1_1Channel.html#af94fab980145dfe7b17b9d8a4e94e815',1,'iio.Channel.id()'],['../classiio_1_1Device.html#a5d206eae4628dc18fdfac1e515674cdc',1,'iio.Device.id()']]],
  ['identify_5ffilename_42',['identify_filename',['../classiio_1_1Device.html#ac68bcd5fa0278c23f2db0d7e35a28dce',1,'iio::Device']]],
  ['iio_43',['iio',['../namespaceiio.html',1,'']]],
  ['iobuffer_44',['IOBuffer',['../classiio_1_1IOBuffer.html',1,'iio.IOBuffer'],['../classiio_1_1IOBuffer.html#acc8526b0e90113f5a5a1376b961d25c0',1,'iio.IOBuffer.IOBuffer()']]],
  ['is_5fenabled_45',['is_enabled',['../classiio_1_1Channel.html#a4768aee0d2271e63867f05c10f541f7c',1,'iio::Channel']]]
];

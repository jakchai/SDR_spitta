var searchData=
[
  ['library_5fversion_132',['library_version',['../classiio_1_1Context.html#abbd75cb9945ab472fdf95a02c4657354',1,'iio::Context']]]
];

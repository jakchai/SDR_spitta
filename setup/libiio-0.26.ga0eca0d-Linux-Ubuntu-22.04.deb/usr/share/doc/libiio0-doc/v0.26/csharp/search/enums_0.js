var searchData=
[
  ['channelmodifier_138',['ChannelModifier',['../classiio_1_1Channel.html#a0fb67718975decc040a97c6cda065eee',1,'iio::Channel']]],
  ['channeltype_139',['ChannelType',['../classiio_1_1Channel.html#a57f13debcf0ff524fb8ae8613c6599da',1,'iio::Channel']]]
];

var searchData=
[
  ['buffer_5fattrs_141',['buffer_attrs',['../classiio_1_1Device.html#af886c74c8e341cb7140ba9474dbd2340',1,'iio::Device']]]
];

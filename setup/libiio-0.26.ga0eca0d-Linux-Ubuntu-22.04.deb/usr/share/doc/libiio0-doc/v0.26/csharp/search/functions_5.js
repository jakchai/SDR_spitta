var searchData=
[
  ['identify_5ffilename_106',['identify_filename',['../classiio_1_1Device.html#ac68bcd5fa0278c23f2db0d7e35a28dce',1,'iio::Device']]],
  ['iobuffer_107',['IOBuffer',['../classiio_1_1IOBuffer.html#acc8526b0e90113f5a5a1376b961d25c0',1,'iio::IOBuffer']]],
  ['is_5fenabled_108',['is_enabled',['../classiio_1_1Channel.html#a4768aee0d2271e63867f05c10f541f7c',1,'iio::Channel']]]
];

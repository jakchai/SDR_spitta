var searchData=
[
  ['samples_5fcount_59',['samples_count',['../classiio_1_1IOBuffer.html#a4b1116135bcf1442b980f07ac32b92ca',1,'iio::IOBuffer']]],
  ['scan_5felement_60',['scan_element',['../classiio_1_1Channel.html#a0a9079a13b55719bfa36b8d041883ecd',1,'iio::Channel']]],
  ['scancontext_61',['ScanContext',['../classiio_1_1ScanContext.html',1,'iio']]],
  ['set_5fblocking_5fmode_62',['set_blocking_mode',['../classiio_1_1IOBuffer.html#adcae94765967aafa22375b21e026c7a8',1,'iio::IOBuffer']]],
  ['set_5fkernel_5fbuffers_5fcount_63',['set_kernel_buffers_count',['../classiio_1_1Device.html#a9005ab45349aa4c98a6717847001d6fd',1,'iio::Device']]],
  ['set_5frate_64',['set_rate',['../classiio_1_1Trigger.html#ab12ed83717ef5ccd390a5912e2f0ab35',1,'iio::Trigger']]],
  ['set_5ftimeout_65',['set_timeout',['../classiio_1_1Context.html#a01a0558b0aec4442e71db52fcbb63793',1,'iio::Context']]],
  ['set_5ftrigger_66',['set_trigger',['../classiio_1_1Device.html#a5cf653e285c685648dfc66a5119595d4',1,'iio.Device.set_trigger()'],['../classiio_1_1Trigger.html#af8c80cf48e924780a1705c20032119c1',1,'iio.Trigger.set_trigger()']]],
  ['step_67',['step',['../classiio_1_1IOBuffer.html#a6bc109c422c32ded351060e83b3a69a1',1,'iio::IOBuffer']]]
];

var searchData=
[
  ['get_5fchannel_29',['get_channel',['../classiio_1_1Device.html#ab7f441c0264fa93c34106df969221d89',1,'iio::Device']]],
  ['get_5fcontext_30',['get_context',['../classiio_1_1Device.html#aecb809422163d179c3b501bbadaa1ae7',1,'iio::Device']]],
  ['get_5fdevice_31',['get_device',['../classiio_1_1Channel.html#a942e10b2242e296bf75f183ea4b841a5',1,'iio.Channel.get_device()'],['../classiio_1_1Context.html#aec3175f0ba17f5e1e378e764a1cc7ce2',1,'iio.Context.get_device()'],['../classiio_1_1IOBuffer.html#a56e996c52498ce2a91dad07f9e535f6d',1,'iio.IOBuffer.get_device()']]],
  ['get_5fdns_5fsd_5fbackend_5fcontexts_32',['get_dns_sd_backend_contexts',['../classiio_1_1ScanContext.html#a097cc76f6b3f5630c0e17db97884bc36',1,'iio::ScanContext']]],
  ['get_5findex_33',['get_index',['../classiio_1_1Channel.html#a89d5dc152580f8bf83597832e073df42',1,'iio::Channel']]],
  ['get_5flocal_5fbackend_5fcontexts_34',['get_local_backend_contexts',['../classiio_1_1ScanContext.html#a3a7e6bbee822fc27f6917a8c20390f9b',1,'iio::ScanContext']]],
  ['get_5fpoll_5ffd_35',['get_poll_fd',['../classiio_1_1IOBuffer.html#a70243ca0b0ae463181af421905525e6d',1,'iio::IOBuffer']]],
  ['get_5frate_36',['get_rate',['../classiio_1_1Trigger.html#a6ad460b6af12673c305862c1d83eb894',1,'iio::Trigger']]],
  ['get_5fsample_5fsize_37',['get_sample_size',['../classiio_1_1Device.html#a8fcf659b560ffae54b8e5e3181d7988f',1,'iio::Device']]],
  ['get_5ftrigger_38',['get_trigger',['../classiio_1_1Device.html#a0d6bcb4c98aa71895c5c9476bb2e7285',1,'iio.Device.get_trigger()'],['../classiio_1_1Trigger.html#a9e5ece91f51e1faf5785ebbd4da0ccba',1,'iio.Trigger.get_trigger()']]],
  ['get_5fusb_5fbackend_5fcontexts_39',['get_usb_backend_contexts',['../classiio_1_1ScanContext.html#a7f05f475f3f8c6ed8a9bb6118b42d52b',1,'iio::ScanContext']]]
];

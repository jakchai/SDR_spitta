var hierarchy =
[
    [ "iio.Attr", "classiio_1_1Attr.html", null ],
    [ "iio.Channel", "classiio_1_1Channel.html", null ],
    [ "iio.Context", "classiio_1_1Context.html", null ],
    [ "iio.Device", "classiio_1_1Device.html", [
      [ "iio.Trigger", "classiio_1_1Trigger.html", null ]
    ] ],
    [ "iio.IOBuffer", "classiio_1_1IOBuffer.html", null ],
    [ "iio.ScanContext", "classiio_1_1ScanContext.html", null ]
];
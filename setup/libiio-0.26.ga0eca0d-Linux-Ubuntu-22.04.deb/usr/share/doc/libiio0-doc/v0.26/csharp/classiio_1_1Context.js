var classiio_1_1Context =
[
    [ "Context", "classiio_1_1Context.html#ad8a25052729c766e84f35084901929e9", null ],
    [ "Context", "classiio_1_1Context.html#ab2a18c05d5455eb3cca59b38953fadf8", null ],
    [ "clone", "classiio_1_1Context.html#a2a39fa7c5e3b7fe684d68a479608f341", null ],
    [ "Dispose", "classiio_1_1Context.html#adc35e6f453bdb4e4209d9e7dee76c0cc", null ],
    [ "find_device", "classiio_1_1Context.html#a9aa5bf7e06b078acab4a7a9567c109bf", null ],
    [ "get_device", "classiio_1_1Context.html#aec3175f0ba17f5e1e378e764a1cc7ce2", null ],
    [ "set_timeout", "classiio_1_1Context.html#a01a0558b0aec4442e71db52fcbb63793", null ],
    [ "description", "classiio_1_1Context.html#ac2612db1cb43a09f4d2f5cb7940a89cf", null ],
    [ "devices", "classiio_1_1Context.html#ad5fc9205417a8a2daacdb3cc9832995c", null ],
    [ "library_version", "classiio_1_1Context.html#abbd75cb9945ab472fdf95a02c4657354", null ],
    [ "name", "classiio_1_1Context.html#a83dd7d2ff7f2269eb4d4546179060954", null ],
    [ "xml", "classiio_1_1Context.html#a9f9eb26f85fc6b41ba10902a7782b88a", null ],
    [ "attrs", "classiio_1_1Context.html#a3eef82f7c710339551dc6dd3475002e3", null ]
];
var searchData=
[
  ['enable_87',['enable',['../classiio_1_1Channel.html#ab0205ddf3f2f16b804eace62557a0610',1,'iio::Channel']]]
];

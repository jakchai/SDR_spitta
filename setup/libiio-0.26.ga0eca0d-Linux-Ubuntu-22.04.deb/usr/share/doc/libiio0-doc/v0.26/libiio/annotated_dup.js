var annotated_dup =
[
    [ "iio_buffer", "structiio__buffer.html", null ],
    [ "iio_channel", "structiio__channel.html", null ],
    [ "iio_context", "structiio__context.html", null ],
    [ "iio_context_info", "structiio__context__info.html", null ],
    [ "iio_data_format", "structiio__data__format.html", "structiio__data__format" ],
    [ "iio_device", "structiio__device.html", null ]
];
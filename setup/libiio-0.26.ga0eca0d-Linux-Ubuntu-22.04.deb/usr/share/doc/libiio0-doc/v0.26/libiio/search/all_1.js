var searchData=
[
  ['channel_2',['Channel',['../group__Channel.html',1,'']]],
  ['compatibility_20with_20hardware_20monitoring_20_28hwmon_29_20devices_3',['Compatibility with hardware monitoring (hwmon) devices',['../group__Hwmon.html',1,'']]],
  ['context_4',['Context',['../group__Context.html',1,'']]]
];

var indexSectionsWithContent =
{
  0: "bcdfhilrstw",
  1: "i",
  2: "i",
  3: "i",
  4: "bilrsw",
  5: "hi",
  6: "bcdft"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Modules"
};


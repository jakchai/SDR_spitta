var modules =
[
    [ "Functions for scanning available contexts", "group__Scan.html", "group__Scan" ],
    [ "Top-level functions", "group__TopLevel.html", "group__TopLevel" ],
    [ "Context", "group__Context.html", "group__Context" ],
    [ "Device", "group__Device.html", "group__Device" ],
    [ "Channel", "group__Channel.html", "group__Channel" ],
    [ "Buffer", "group__Buffer.html", "group__Buffer" ],
    [ "Compatibility with hardware monitoring (hwmon) devices", "group__Hwmon.html", "group__Hwmon" ],
    [ "Debug and low-level functions", "group__Debug.html", "group__Debug" ]
];
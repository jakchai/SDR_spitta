var group__Hwmon =
[
    [ "hwmon_chan_type", "group__Hwmon.html#gad195944ed700c0f550b7dd4764bdda2e", null ]
];
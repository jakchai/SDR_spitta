var searchData=
[
  ['is_5fbe_325',['is_be',['../structiio__data__format.html#a1c1775c482b9b4c3f1dfa0b67ad6fbaa',1,'iio_data_format']]],
  ['is_5ffully_5fdefined_326',['is_fully_defined',['../structiio__data__format.html#a86c382f0ff1dcf40f68f261d2d81caf5',1,'iio_data_format']]],
  ['is_5fsigned_327',['is_signed',['../structiio__data__format.html#a173f2fb6931c4215e53d934667f0dc3f',1,'iio_data_format']]]
];

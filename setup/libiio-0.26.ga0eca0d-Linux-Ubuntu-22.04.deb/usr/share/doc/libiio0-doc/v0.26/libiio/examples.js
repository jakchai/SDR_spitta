var examples =
[
    [ "iio_attr.c", "iio_attr_8c-example.html", null ],
    [ "iio_info.c", "iio_info_8c-example.html", null ],
    [ "iio_readdev.c", "iio_readdev_8c-example.html", null ],
    [ "iio_writedev.c", "iio_writedev_8c-example.html", null ],
    [ "iio_reg.c", "iio_reg_8c-example.html", null ],
    [ "ad9361-iiostream.c", "ad9361-iiostream_8c-example.html", null ],
    [ "ad9371-iiostream.c", "ad9371-iiostream_8c-example.html", null ],
    [ "adrv9009-iiostream.c", "adrv9009-iiostream_8c-example.html", null ],
    [ "dummy-iiostream.c", "dummy-iiostream_8c-example.html", null ],
    [ "iio-monitor.c", "iio-monitor_8c-example.html", null ]
];
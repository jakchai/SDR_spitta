Device
==================

Members
--------------
.. autoclass:: iio.Device
   :members:
   :inherited-members:

------------------

Device attributes
------------------
.. autoclass:: iio.DeviceDebugAttr
   :members:
   :inherited-members:
.. autoclass:: iio.DeviceBufferAttr
   :members:
   :inherited-members:


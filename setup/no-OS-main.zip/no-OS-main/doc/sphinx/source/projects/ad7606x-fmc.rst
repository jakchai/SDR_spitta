.. include:: ../../../../projects/ad7606x-fmc/README.rst

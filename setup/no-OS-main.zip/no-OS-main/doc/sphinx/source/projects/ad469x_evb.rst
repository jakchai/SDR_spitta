.. include:: ../../../../projects/ad469x_evb/README.rst

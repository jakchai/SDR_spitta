.. include:: ../../../../projects/pulsar-adc/README.rst

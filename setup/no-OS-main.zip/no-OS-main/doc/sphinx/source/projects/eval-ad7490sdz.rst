.. include:: ../../../../projects/eval-ad7490sdz/README.rst

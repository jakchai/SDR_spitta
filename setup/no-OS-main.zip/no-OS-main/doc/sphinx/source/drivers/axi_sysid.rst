.. include:: ../../../../drivers/axi_core/axi_sysid/README.rst

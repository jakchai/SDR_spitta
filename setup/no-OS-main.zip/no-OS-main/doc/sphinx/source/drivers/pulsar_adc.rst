.. include:: ../../../../drivers/adc/pulsar_adc/README.rst
